import discord
from discord.ext import commands

class antiplv(commands.Cog):
   def __init__(self, client):
       self.client = client

   @commands.Cog.listener()
   async def on_message(self, message):

    if not message.guild or message.author.bot: #ignorar monitorando de msg privada e mensagens do bot
        return

    badwords = {
        "exact": ["filha da puta", "vai tomar no cu"], #exact = palavras que serão censuradas se não tiver outros caracteres próximos, exemplo: palavrão1 palavrão2 (não vai censurar algo do tipo: palavrão1234)
        "any": ["cu", "xota"]

    }
    censored_message = [message.content]

    for badword in badwords["exact"]:
    	await message.delete() #deletar mensagem origina
    	await message.channel.send(f'**{message.author.mention} Você não pode falar palavras de baixo calão neste servidor.**')

    if censored_message[0] == message.content.lower(): #caso a mensagem não seja censurada, vamos apenas ignorar
        return

    await message.delete() #deletar mensagem original
    await message.channel.send(f'**{message.author.mention} Você não pode falar palavras de baixo calão neste servidor.**')
	
if "discord.gg" in message.content.lower():
	if not message.
	await message.delete()
	await message.channel.send(f'**{message.author.mention} Você não pode divulgar servidores aqui!**')
    
def setup(client):
    print("[Andtiplv] Carregado")
    client.add_cog(antiplv(client))    