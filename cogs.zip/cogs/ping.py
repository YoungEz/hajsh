import discord, time, datetime
from discord.ext import commands

class PingMS(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        @commands.command()
        async def ping(self, ctx):
        	ptime = time.time()
        	embed = discord.Embed(Title='Ping', color=0x00FF00)
        	embed.add_field(name='Pong!', value='Calculando...')
        	embed.set_author(name=f'{ctx.message.author.display_name}', icon_url=f'{ctx.message.author.avatar_url}')
        	ping3 = await ctx.send(embed=embed)
        	ping2 = time.time() - ptime
        	ping1 = discord.Embed(Title='Ping', color=0x00FF00)
        	ping1.add_field(name='Pong!', value='{} ms.'.format(int((round(ping2 * 1000)))))
        	ping1.set_author(name=f'{ctx.message.author.display_name}', icon_url=f'{ctx.message.author.avatar_url}')
        	await ping3.edit(embed=ping1)
    
def setup(client):
    print("[Comando ping e Carregado.")
    client.add_cog(PingMS(client))    