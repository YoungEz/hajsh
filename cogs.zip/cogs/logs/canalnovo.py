import json
import discord

from discord.ext import commands



class ChannelCreate(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
    	canal = self.bot.get_channel(582930274430746644)

    	to_send = discord.Embed(title=":star2: **Canal de texto criado**",color=0xff0000,description=f"**Canal de texto:** {channel.mention}")
    	to_send.set_footer(text="ShiryuVipZ®")
    	await canal.send(embed=to_send)



def setup(bot):
    bot.add_cog(ChannelCreate(bot))
    print('\033[1;32mO evento \033[1;34mCHANNEL_CREATE\033[1;32m foi carregado com sucesso!\33[m')
