import json
import discord

from discord.ext import commands




class ChannelPinUpdate(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_guild_channel_pins_update(self, channel, last_pin):
        canal = self.bot.get_channel(582930274430746644)
        if last_pin is not None:
        	fix_ = 'fixada'
        	time_ = '\n em: ' + str(last_pin)
        else:
        	fix_ = 'desfixada'
        	time_ = '\n'
        	to_send = discord.Embed(title=f":bangbang: **Uma mensagem foi {fix_}**",color=0xff00ab,description=f"**Canal de texto:** {channel.name} {time_}")
        	to_send.set_footer(text="Shiryu ®.")
        	await canal.send(embed=to_send)



def setup(bot):
    bot.add_cog(ChannelPinUpdate(bot))
    print('\033[1;32mO evento \033[1;34mCHANNEL_PINS_UPDATE\033[1;32m foi carregado com sucesso!\33[m')
